# 请输入xxx_xxx_xxx的md5值
import hashlib

scan_ip = "" # 被攻击的ip地址
first_scan_port = "" # 扫描的第一个端口
username = "" # 使用的用户名
password = "" # 使用的密码
file = "" # 下载的文件(包括后缀)

flag = hashlib.md5((scan_ip+ first_scan_port + username + password + file).encode()).hexdigest()

print(flag) # flag请以flag{xxx}格式提交